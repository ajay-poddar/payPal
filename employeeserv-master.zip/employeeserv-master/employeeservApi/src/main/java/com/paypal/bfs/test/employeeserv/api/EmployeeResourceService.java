package com.paypal.bfs.test.employeeserv.api;

import com.paypal.bfs.test.employeeserv.api.model.Employee;

public interface EmployeeResourceService {

    public Employee employeeGetById(String id);

    public Employee createEmployee(Employee employee);
}
