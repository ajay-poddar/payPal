package com.paypal.bfs.test.employeeserv.api;

import com.paypal.bfs.test.employeeserv.api.model.Employee;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

/**
 * Interface for employee resource operations.
 */
public interface EmployeeResource {

    /**
     * Retrieves the {@link Employee} resource by id.
     *
     * @param id employee id.
     * @return {@link Employee} resource.
     */
    @RequestMapping("/v1/bfs/employees/{id}")
    ResponseEntity<Employee> employeeGetById(@NotBlank @PathVariable("id") String id);

    /**
     * Creates the {@link Employee} resource.
     *
     * @param employee Employee.
     * @return {@link Employee} resource.
     * Sample Request
     * {
     *  "first_name":"ajay",
     *  "last_name":"poddar",
     *  "date_of_birth":"06/04/1994",
     *  "address": {
     *       "line1": "a",
     *       "line2":"c",
     *       "city":"s",
     *       "state": "w",
     *       "country": "w",
     *       "zip_code": 123456
     *   }
     * }
     */
    @RequestMapping("/v1/bfs/employee/create")
    ResponseEntity<Employee> createEmployee(@Valid @RequestBody Employee employee);
}
