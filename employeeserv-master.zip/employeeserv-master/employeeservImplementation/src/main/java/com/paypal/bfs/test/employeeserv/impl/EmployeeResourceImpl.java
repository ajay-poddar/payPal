package com.paypal.bfs.test.employeeserv.impl;

import com.paypal.bfs.test.employeeserv.api.EmployeeResource;
import com.paypal.bfs.test.employeeserv.api.EmployeeResourceService;
import com.paypal.bfs.test.employeeserv.api.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 * Implementation class for employee resource.
 */
@RestController
public class EmployeeResourceImpl implements EmployeeResource {

    @Autowired
    EmployeeResourceService employeeResourceService;

    @Override
    public ResponseEntity<Employee> employeeGetById(String id) {
        Employee employee=employeeResourceService.employeeGetById(id);
        if (employee==null)
            return new ResponseEntity<>(new Employee(), HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(employee, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Employee> createEmployee(Employee employee) {
        employee=employeeResourceService.createEmployee(employee);
        if (employee==null)
            return new ResponseEntity<>(new Employee(), HttpStatus.INTERNAL_SERVER_ERROR);
        return new ResponseEntity<>(employee, HttpStatus.OK);
    }
}
