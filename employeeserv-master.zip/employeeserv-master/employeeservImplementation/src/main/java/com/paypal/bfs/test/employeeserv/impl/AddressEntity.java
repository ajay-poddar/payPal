package com.paypal.bfs.test.employeeserv.impl;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Embeddable;

@Embeddable
@Getter
@Setter
public class AddressEntity {

    private String line1;

    private String line2;

    private String city;

    private String state;

    private String country;

    private Integer zipCode;
}
