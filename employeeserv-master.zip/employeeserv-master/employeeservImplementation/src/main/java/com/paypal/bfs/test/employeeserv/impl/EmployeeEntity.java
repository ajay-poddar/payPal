package com.paypal.bfs.test.employeeserv.impl;

import com.paypal.bfs.test.employeeserv.util.IdGenerationUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Getter
@NoArgsConstructor
public class EmployeeEntity {

    @Id
    @Column
    private Integer id;

    @Column
    private String firstName;

    @Column
    private String lastName;

    @Column
    private String dateOfBirth;

    @Embedded
    @Column
    private AddressEntity address;

    public EmployeeEntity(String firstName, String lastName, String dateOfBirth, AddressEntity address) {
        this.id= IdGenerationUtil.createId();
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
    }

    public void setAddress(AddressEntity address) {
        this.address = address;
    }
}
