package com.paypal.bfs.test.employeeserv.util;

public class IdGenerationUtil {
    private static Integer id=0;

    public static synchronized Integer createId(){
        id+=1;
        return id;
    }
}
