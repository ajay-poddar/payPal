package com.paypal.bfs.test.employeeserv.Exception;

public class InvalidArgumentException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public InvalidArgumentException(String exception) {
        super(exception);
    }
}
