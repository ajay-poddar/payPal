package com.paypal.bfs.test.employeeserv.impl;

import com.paypal.bfs.test.employeeserv.Exception.InvalidArgumentException;
import com.paypal.bfs.test.employeeserv.api.EmployeeResourceService;
import com.paypal.bfs.test.employeeserv.api.model.Address;
import com.paypal.bfs.test.employeeserv.api.model.Employee;
import com.paypal.bfs.test.employeeserv.util.DateMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeResourceServiceImpl implements EmployeeResourceService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Override
    public Employee employeeGetById(String id) {
        EmployeeEntity employeeEntity=employeeRepository.findById(Integer.valueOf(id)).orElse(null);
        if(employeeEntity==null)
            return null;

        return toEmployeeMapper(employeeEntity);
    }

    @Override
    public Employee createEmployee(Employee employee) {
        if(!DateMatcher.matches(employee.getDateOfBirth()))
            throw new InvalidArgumentException("Invalid Date Of Birth");
        EmployeeEntity employeeEntity=employeeRepository.save(toEmployeeEntityMapper(employee));
        if(employeeEntity==null)
            return null;
        employee.setId(employeeEntity.getId());
        return employee;
    }

    private EmployeeEntity toEmployeeEntityMapper(Employee employee){

        AddressEntity addressEntity=new AddressEntity();
        addressEntity.setLine1(employee.getAddress().getLine1());
        addressEntity.setLine2(employee.getAddress().getLine2());
        addressEntity.setCity(employee.getAddress().getCity());
        addressEntity.setState(employee.getAddress().getState());
        addressEntity.setCountry(employee.getAddress().getCountry());
        addressEntity.setZipCode(employee.getAddress().getZipCode());

        EmployeeEntity employeeEntity=new EmployeeEntity(employee.getFirstName(), employee.getLastName(), employee.getDateOfBirth(), addressEntity);
        return employeeEntity;
    }
    private Employee toEmployeeMapper(EmployeeEntity employeeEntity){
        Address address=new Address();
        address.setLine1(employeeEntity.getAddress().getLine1());
        address.setLine2(employeeEntity.getAddress().getLine2());
        address.setCity(employeeEntity.getAddress().getCity());
        address.setState(employeeEntity.getAddress().getState());
        address.setCountry(employeeEntity.getAddress().getCountry());
        address.setZipCode(employeeEntity.getAddress().getZipCode());

        Employee employee=new Employee();
        employee.setId(employeeEntity.getId());
        employee.setFirstName(employeeEntity.getFirstName());
        employee.setLastName(employeeEntity.getLastName());
        employee.setDateOfBirth(employeeEntity.getDateOfBirth());
        employee.setAddress(address);
        return employee;
    }
}
