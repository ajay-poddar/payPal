import com.paypal.bfs.test.employeeserv.EmployeeservApplication;
import com.paypal.bfs.test.employeeserv.api.EmployeeResourceService;
import com.paypal.bfs.test.employeeserv.api.model.Address;
import com.paypal.bfs.test.employeeserv.api.model.Employee;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=EmployeeservApplication.class)
@AutoConfigureMockMvc
public class EmployeeResourceTest {

    @Autowired
    EmployeeResourceService employeeResourceService;

    @Test
    public void contextLoads()  {
    }

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testGetEmployeeForInvalidId() throws Exception {
        this.mockMvc.perform(get("/v1/bfs/employees/1")).andDo(print()).andExpect(status().isNotFound());

    }

    @Test
    public void testGetEmployeeForValidId() throws Exception {
        createEmployee();
        this.mockMvc.perform(get("/v1/bfs/employees/1")).andDo(print()).andExpect(status().isOk());

    }

    @Test
    public void testGetEmployeeForBothValidAndInvalidId() throws Exception {
        createEmployee();
        this.mockMvc.perform(get("/v1/bfs/employees/1")).andDo(print()).andExpect(status().isOk());
        this.mockMvc.perform(get("/v1/bfs/employees/2")).andDo(print()).andExpect(status().isNotFound());

    }

    @Test
    public void testCreateValidEmployee() throws Exception {
        this.mockMvc.perform(post("/v1/bfs/employee/create")
        .contentType(MediaType.APPLICATION_JSON)
        .content("{\n" +
                " \"first_name\":\"ajay\",\n" +
                " \"last_name\":\"poddar\",\n" +
                " \"date_of_birth\":\"06/04/1994\",\n" +
                " \"address\": {\n" +
                "      \"line1\": \"a\",\n" +
                "      \"line2\":\"c\",\n" +
                "      \"city\":\"s\",\n" +
                "      \"state\": \"w\",\n" +
                "      \"country\": \"w\",\n" +
                "      \"zip_code\": 123456\n" +
                "  }\n" +
                "}")).andDo(print()).andExpect(status().isOk());

    }

    @Test
    public void testCreateInValidEmployeeDOB() throws Exception {
        this.mockMvc.perform(post("/v1/bfs/employee/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\n" +
                        " \"first_name\":\"ajay\",\n" +
                        " \"last_name\":\"poddar\",\n" +
                        " \"date_of_birth\":\"06041994\",\n" +
                        " \"address\": {\n" +
                        "      \"line1\": \"a\",\n" +
                        "      \"line2\":\"c\",\n" +
                        "      \"city\":\"s\",\n" +
                        "      \"state\": \"w\",\n" +
                        "      \"country\": \"w\",\n" +
                        "      \"zip_code\": 123456\n" +
                        "  }\n" +
                        "}")).andDo(print()).andExpect(status().isBadRequest());

    }

    @Test
    public void testCreateValidEmployeeWithoutLine2() throws Exception {
        this.mockMvc.perform(post("/v1/bfs/employee/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\n" +
                        " \"first_name\":\"ajay\",\n" +
                        " \"last_name\":\"poddar\",\n" +
                        " \"date_of_birth\":\"06/04/1994\",\n" +
                        " \"address\": {\n" +
                        "      \"line1\": \"a\",\n" +
                        "      \"city\":\"s\",\n" +
                        "      \"state\": \"w\",\n" +
                        "      \"country\": \"w\",\n" +
                        "      \"zip_code\": 123456\n" +
                        "  }\n" +
                        "}")).andDo(print()).andExpect(status().isOk());

    }

    //any notnull field can be removed to test this
    @Test
    public void testCreateInValidEmployee() throws Exception {
        this.mockMvc.perform(post("/v1/bfs/employee/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\n" +
                        " \"first_name\":\"ajay\",\n" +
                        " \"date_of_birth\":\"06/04/1994\",\n" +
                        " \"address\": {\n" +
                        "      \"line2\":\"c\",\n" +
                        "      \"city\":\"s\",\n" +
                        "      \"state\": \"w\",\n" +
                        "      \"country\": \"w\",\n" +
                        "      \"zip_code\": 123456\n" +
                        "  }\n" +
                        "}")).andDo(print()).andExpect(status().isBadRequest());

    }

    private Employee createEmployee(){
        Address address=new Address();
        address.setLine1("a");
        address.setLine2("b");
        address.setCity("c");
        address.setState("d");
        address.setCountry("e");
        address.setZipCode(123456);

        Employee employee=new Employee();
        employee.setFirstName("ajay");
        employee.setLastName("poddar");
        employee.setDateOfBirth("06/04/1994");
        employee.setAddress(address);
        return employeeResourceService.createEmployee(employee);
    }

}
